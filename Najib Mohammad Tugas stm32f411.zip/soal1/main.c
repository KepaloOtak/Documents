//Najib Mohammad (101032400109), soal 1
#include "stm32f4xx.h"

static void gpio_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;            

    GPIOB->MODER &= ~((3U << 0) | (3U << 2) | (3U << 4));
    GPIOB->MODER |=  ((1U << 0) | (1U << 2) | (1U << 4));
}

static void timer_init(TIM_TypeDef *tim, uint32_t psc, uint32_t arr, IRQn_Type irq)
{
    tim->PSC  = psc;
    tim->ARR  = arr;
    tim->EGR  = TIM_EGR_UG;       
    tim->SR   = 0;                 
    tim->DIER |= TIM_DIER_UIE;    
    NVIC_EnableIRQ(irq);
    tim->CR1  |= TIM_CR1_CEN;   
}

int main(void)
{
    gpio_init();

    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN | RCC_APB1ENR_TIM3EN | RCC_APB1ENR_TIM4EN;

    timer_init(TIM2, 15999, 499, TIM2_IRQn);   
    timer_init(TIM3, 15999, 249, TIM3_IRQn);  
    timer_init(TIM4, 15999,  99, TIM4_IRQn);

    while (1) {
    }
}

void TIM2_IRQHandler(void)
{
    if (TIM2->SR & TIM_SR_UIF) {
        TIM2->SR &= ~TIM_SR_UIF;
        GPIOB->ODR ^= (1U << 0);
    }
}

void TIM3_IRQHandler(void)
{
    if (TIM3->SR & TIM_SR_UIF) {
        TIM3->SR &= ~TIM_SR_UIF;
        GPIOB->ODR ^= (1U << 1);
    }
}

void TIM4_IRQHandler(void)
{
    if (TIM4->SR & TIM_SR_UIF) {
        TIM4->SR &= ~TIM_SR_UIF;
        GPIOB->ODR ^= (1U << 2);
    }
}
