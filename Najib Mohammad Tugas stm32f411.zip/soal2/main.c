//Najib Mohammad (101032400109), soal 2
#include "stm32f4xx.h"

#define LED_PIN        5U      
#define BTN_PIN        13U     
#define DEBOUNCE_MS    20U

volatile uint8_t btn_sem = 0;  

static void gpio_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOCEN;

    GPIOA->MODER &= ~(3U << (LED_PIN * 2));
    GPIOA->MODER |=  (1U << (LED_PIN * 2));

    GPIOC->MODER &= ~(3U << (BTN_PIN * 2));
    GPIOC->PUPDR &= ~(3U << (BTN_PIN * 2));
    GPIOC->PUPDR |=  (1U << (BTN_PIN * 2));
}

static void exti_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;

    SYSCFG->EXTICR[3] &= ~(0xFU << 4);
    SYSCFG->EXTICR[3] |=  (0x2U << 4);

    EXTI->FTSR |= (1U << BTN_PIN);     
    EXTI->PR    = (1U << BTN_PIN);      
    EXTI->IMR  |= (1U << BTN_PIN);     

    NVIC_EnableIRQ(EXTI15_10_IRQn);
}

static void tim5_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM5EN;

    TIM5->PSC = 15999;                  
    TIM5->ARR = DEBOUNCE_MS - 1U;      
    TIM5->CR1 |= TIM_CR1_OPM;           
    TIM5->EGR = TIM_EGR_UG;
    TIM5->SR  = 0;
    TIM5->DIER |= TIM_DIER_UIE;

    NVIC_EnableIRQ(TIM5_IRQn);
}

int main(void)
{
    gpio_init();
    tim5_init();
    exti_init();

    while (1) {
        if (btn_sem) {
            btn_sem = 0;                       
            GPIOA->ODR ^= (1U << LED_PIN);   
        }
    }
}

void EXTI15_10_IRQHandler(void)
{
    if (EXTI->PR & (1U << BTN_PIN)) {
        EXTI->PR   = (1U << BTN_PIN);          
        EXTI->IMR &= ~(1U << BTN_PIN);         
        TIM5->CNT  = 0;
        TIM5->CR1 |= TIM_CR1_CEN;             
    }
}

void TIM5_IRQHandler(void)
{
    if (TIM5->SR & TIM_SR_UIF) {
        TIM5->SR &= ~TIM_SR_UIF;

        if ((GPIOC->IDR & (1U << BTN_PIN)) == 0U) {   
            btn_sem = 1;                              
        }
        EXTI->PR   = (1U << BTN_PIN);                
        EXTI->IMR |= (1U << BTN_PIN);                
    }
}
